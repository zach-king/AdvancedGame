#ifndef DEFINITIONS_H
#define DEFINITIONS_H

//Declaration of condition enumeration
enum END_CONDITION{WIN, LOSE, NONE, QUIT};

#endif